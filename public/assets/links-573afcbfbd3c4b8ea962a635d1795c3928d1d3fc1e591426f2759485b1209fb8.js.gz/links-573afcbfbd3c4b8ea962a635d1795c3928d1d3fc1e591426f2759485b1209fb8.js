function invest() {
	window.location = "/companies";
}
function auction() {
	window.location = "/auction";
}

function dreamfunded_portfolio() {
	window.location = "dreamfunded_portfolio";
}

function profile() {
	window.location = "/users/profile";
}

function signOut() {
	window.location = "/users/sign_out";
}

function signUp() {
	window.location = "/users/sign_up";
}

function about() {
	window.location = "/about";
}

function team() {
	window.location = "/team";
}

function faq() {
	window.location = "/faq";
}
function advisors() {
	window.location = "/mentors";
}

function contact() {
	window.location = "/contact";
}

function funding() {
	window.location = "/companies/new";
}

function exchange() {
	window.location = "home/exchange";
}

function news() {
	window.location = "/news"
}

function whyInv() {
	window.location = "/home/why";
}

function login() {
	window.location = "/users/sign_in";
}
function signIn() {
	window.location = "/users/sign_up";
}

function home() {
	window.location = "/";
}

function portfolio() {
	window.location = "/users/portfolio";
}

function admin() {
	window.location = "/admin/write";
}
function government_admin() {
	window.location = "/admin/admin";
}

function legal() {
	window.location = "/home/legal";
}
function how_it_works() {
	window.location = "/how_it_works";
}
function get_funded(){
	window.location = "/campaign_basics";
}
function invite(){
	window.location = "/invite";
}
function press(){
	window.location = "/press";
}
function manny(){
	window.location = "/manny-fernandez";
}
function rexford(){
	window.location = "/rexford-r-hibbs";
}
function campaign(){
	window.location = "/my_campaigns";
}
function blog(){
	window.location = "/blog";
}
function svexchange(){
	window.location = "http://svexchange.com/";
}
function diversity_network(){
	window.location = "/diversitynetwork";
}
function group(){
	window.location = "/my_group";
}
;
